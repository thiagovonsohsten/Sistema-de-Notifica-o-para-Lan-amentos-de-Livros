import pika

EXCHANGE_NAME = 'book_topic_exchange'

def callback(ch, method, properties, body):
    print(f"[AUDITORIA] Mensagem auditada com chave de roteamento '{method.routing_key}':\n{body.decode()}")

# Conexão com RabbitMQ
connection = pika.BlockingConnection(pika.ConnectionParameters('localhost'))
channel = connection.channel()

# Declarar o exchange como topic
channel.exchange_declare(exchange=EXCHANGE_NAME, exchange_type='topic')

# Criar uma fila temporária para auditoria
result = channel.queue_declare(queue='', exclusive=True)
queue_name = result.method.queue

# Vincular a fila ao exchange usando uma routing key que captura tudo
channel.queue_bind(exchange=EXCHANGE_NAME, queue=queue_name, routing_key='#')

print(' [*] Auditoria esperando mensagens de todos os tópicos. Para sair, pressione CTRL+C')

# Consumir mensagens
channel.basic_consume(queue=queue_name, on_message_callback=callback, auto_ack=True)
channel.start_consuming()
