import pika

EXCHANGE_NAME = 'book_topic_exchange'

def callback(ch, method, properties, body):
    print(f" [x] Recebido com chave de roteamento '{method.routing_key}':\n{body.decode()}")

# Conexão com RabbitMQ
connection = pika.BlockingConnection(pika.ConnectionParameters('localhost'))
channel = connection.channel()

# Declarar o exchange como topic
channel.exchange_declare(exchange=EXCHANGE_NAME, exchange_type='topic')

# Criar uma fila temporária
result = channel.queue_declare(queue='', exclusive=True)
queue_name = result.method.queue

# Vincular a fila ao exchange usando uma routing key
print("Informe a chave de roteamento que deseja se inscrever (ex: livros.*, livros.ficcao):")
routing_key = input()

channel.queue_bind(exchange=EXCHANGE_NAME, queue=queue_name, routing_key=routing_key)

print(f' [*] Aguardando mensagens para o tópico "{routing_key}". Para sair, pressione CTRL+C')

# Consumir mensagens
channel.basic_consume(queue=queue_name, on_message_callback=callback, auto_ack=True)
channel.start_consuming()
