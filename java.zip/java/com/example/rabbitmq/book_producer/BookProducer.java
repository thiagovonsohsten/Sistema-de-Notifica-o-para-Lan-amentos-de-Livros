package com.example.rabbitmq.book_producer;
import com.rabbitmq.client.ConnectionFactory;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.Channel;
import java.nio.charset.StandardCharsets;
import java.util.Scanner;

public class BookProducer {

    private final static String EXCHANGE_NAME = "book_topic_exchange";

    public static void main(String[] argv) throws Exception {
        // Conexão com o RabbitMQ
        ConnectionFactory factory = new ConnectionFactory();
        factory.setHost("localhost");
        try (Connection connection = factory.newConnection(); Channel channel = connection.createChannel()) {
            // Declarar um exchange do tipo topic
            channel.exchangeDeclare(EXCHANGE_NAME, "topic");

            Scanner scanner = new Scanner(System.in);
            while (true) {
                // Coletar informações sobre o livro
                System.out.println("Informe o título do livro:");
                String title = scanner.nextLine();
                System.out.println("Informe a descrição do livro:");
                String description = scanner.nextLine();
                System.out.println("Informe o preço do livro:");
                String price = scanner.nextLine();
                System.out.println("Informe o nome do autor:");
                String author = scanner.nextLine();
                System.out.println("Informe o nome da editora:");
                String publisher = scanner.nextLine();
                System.out.println("Informe a chave de roteamento (ex: livros.ficcao, livros.educacao):");
                String routingKey = scanner.nextLine();

                // Formatar a mensagem com todas as informações
                String message = String.format(
                    "[%s] %s\nTítulo: %s\nDescrição: %s\nPreço: %s\nAutor: %s\nEditora: %s",
                    java.time.LocalDateTime.now(), 
                    "Produtor", 
                    title, 
                    description, 
                    price, 
                    author, 
                    publisher
                );

                // Enviar mensagem com uma routing key
                channel.basicPublish(EXCHANGE_NAME, routingKey, null, message.getBytes(StandardCharsets.UTF_8));
                System.out.println(" [x] Enviado: '" + message + "' com chave de roteamento '" + routingKey + "'");

                // Verificar se o usuário deseja enviar outra mensagem
                System.out.println("Deseja enviar outra mensagem? (s/n)");
                String answer = scanner.nextLine();
                if (answer.equalsIgnoreCase("n")) {
                    break;
                }
            }
        }
    }
}
