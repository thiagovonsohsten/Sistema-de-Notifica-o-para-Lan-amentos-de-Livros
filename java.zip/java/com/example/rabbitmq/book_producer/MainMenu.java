package com.example.rabbitmq.book_producer;
import java.util.Scanner;

public class MainMenu {

    public static void main(String[] args) throws Exception {
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("==============================================");
            System.out.println("|         Sistema de Notificação de Livros   |");
            System.out.println("==============================================");
            System.out.println("|   Escolha uma opção:                       |");
            System.out.println("|   1. Executar Produtor (Java)              |");
            System.out.println("|   2. Executar Consumidor (Python)          |");
            System.out.println("|   3. Executar Auditoria (Python)           |");
            System.out.println("|   4. Sair                                  |");
            System.out.println("==============================================");
            System.out.print("Digite sua escolha: ");

            int choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    System.out.println("\n==> Iniciando o Produtor de Mensagens...");
                    BookProducer.main(args);  // Executa o produtor
                    break;
                case 2:
                    System.out.println("\n==> Por favor, execute o Consumidor usando o seguinte comando:");
                    System.out.println("==> Comando: python3 consumidor.py\n");
                    break;
                case 3:
                    System.out.println("\n==> Por favor, execute o Backend de Auditoria usando o seguinte comando:");
                    System.out.println("==> Comando: python3 auditoria.py\n");
                    break;
                case 4:
                    System.out.println("\n==> Saindo do sistema. Até mais!");
                    System.exit(0);
                    break;
                default:
                    System.out.println("\n==> Opção inválida. Tente novamente!\n");
                    break;
            }

            System.out.println("Pressione Enter para voltar ao menu...");
            scanner.nextLine();  // Pausar até o usuário pressionar Enter
            scanner.nextLine();  // Consumir a nova linha
        }
    }
}
